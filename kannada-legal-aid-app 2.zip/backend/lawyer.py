import os
import tempfile
import PyPDF2
from datetime import datetime
from groq import Groq
import speech_recognition as sr
import dwani
from pydub import AudioSegment
from dotenv import load_dotenv

load_dotenv()

# Configure dwani for TTS only
dwani.api_key = 'kirannskl100@gmail.com_dwani'
dwani.api_base = 'https://dwani-dwani-api.hf.space'

class LawyerProcessor:
    def __init__(self):
        self.client = Groq(api_key=os.getenv("GROQ_API_KEY"))
        self.conversation_history = []
        self.recognizer = sr.Recognizer()
        self.temp_files = []

    def extract_text_from_file(self, file_path):
        """Extract text from uploaded file (PDF or text)."""
        try:
            if not file_path or not os.path.exists(file_path):
                return "ಫೈಲ್ ಕಂಡುಬಂದಿಲ್ಲ / File not found."
            
            if file_path.endswith('.pdf'):
                with open(file_path, 'rb') as file:
                    reader = PyPDF2.PdfReader(file)
                    text = ""
                    for page in reader.pages:
                        text += page.extract_text() or ""
                    return text if text.strip() else "ಪಿಡಿಎಫ್‌ನಿಂದ ಪಠ್ಯವನ್ನು ತೆಗೆಯಲಾಗಲಿಲ್ಲ / No text could be extracted from PDF."
            
            elif file_path.endswith('.txt'):
                with open(file_path, 'r', encoding='utf-8') as file:
                    return file.read()
            
            else:
                return "ಬೆಂಬಲಿತವಾಗದ ಫೈಲ್ ಫಾರ್ಮ್ಯಾಟ್ / Unsupported file format."
        
        except Exception as e:
            return f"ಫೈಲ್ ಓದುವಲ್ಲಿ ದೋಷ: {str(e)} / Error reading file: {str(e)}"

    def save_uploaded_file(self, file):
        """Save uploaded file and return path."""
        try:
            filename = file.filename
            file_path = os.path.join('uploads', filename)
            file.save(file_path)
            return file_path
        except Exception as e:
            raise Exception(f"File upload failed: {str(e)}")

    def transcribe_audio(self, audio_file):
        """Transcribe audio using Google Speech Recognition."""
        try:
            # Save audio file temporarily
            temp_path = os.path.join('temp', f"audio_{datetime.now().strftime('%Y%m%d_%H%M%S')}.wav")
            audio_file.save(temp_path)
            
            # Convert to WAV if needed
            try:
                audio = AudioSegment.from_file(temp_path)
                wav_path = temp_path.replace('.wav', '_converted.wav')
                audio.export(wav_path, format="wav")
                temp_path = wav_path
            except:
                pass  # If conversion fails, try with original file
            
            # Transcribe using speech_recognition
            with sr.AudioFile(temp_path) as source:
                audio_data = self.recognizer.record(source)
                
            # Try Google Speech Recognition first
            try:
                transcription = self.recognizer.recognize_google(audio_data, language='kn-IN')
                return transcription
            except sr.UnknownValueError:
                # Fallback to English if Kannada fails
                try:
                    transcription = self.recognizer.recognize_google(audio_data, language='en-IN')
                    return transcription
                except:
                    raise Exception("ಆಡಿಯೋ ಅರ್ಥಮಾಡಿಕೊಳ್ಳಲಾಗಲಿಲ್ಲ / Could not understand audio")
            
        except Exception as e:
            raise Exception(f"ಲಿಪ್ಯಂತರದಲ್ಲಿ ದೋಷ: {str(e)} / Transcription error: {str(e)}")
        
        finally:
            # Clean up temporary files
            try:
                if os.path.exists(temp_path):
                    os.remove(temp_path)
            except:
                pass

    def process_query(self, query, uploaded_file=None):
        """Process legal query for lawyers."""
        try:
            # Extract file content if provided
            file_content = ""
            if uploaded_file:
                file_content = self.extract_text_from_file(uploaded_file)
            
            # Format conversation history
            history_text = ""
            if self.conversation_history:
                history_text = "Previous conversation:\n" + "\n".join(
                    [f"Q: {entry['query']}\nA: {entry['response']}" for entry in self.conversation_history[-3:]]
                ) + "\n\n"
            
            # Create prompt
            prompt = f"""
            You are a legal aid assistant for Kannada-speaking lawyers. Provide professional, 
            clear responses in Kannada. Include relevant legal information and procedures.
            
            {history_text}
            Document content: {file_content[:1000] if file_content else "None"}
            
            Current query: {query}
            
            Provide a comprehensive response in Kannada:
            """
            
            # Get response from Groq
            response = self.client.chat.completions.create(
                model="llama-3.1-70b-versatile",
                messages=[
                    {"role": "system", "content": "You are a legal aid assistant for lawyers. Respond in Kannada with professional legal guidance."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=800,
                temperature=0.7
            )
            
            kannada_response = response.choices[0].message.content
            
            # Add disclaimer and follow-up
            full_response = (
                f"{kannada_response}\n\n"
                "**ನಿರಾಕರಣೆ**: ಈ ಮಾಹಿತಿಯು ಸಾಮಾನ್ಯ ಮಾರ್ಗದರ್ಶನಕ್ಕಾಗಿ ಮಾತ್ರ. ಕಾನೂನು ಕಾರ್ಯಗಳಿಗೆ ಬಳಸುವ ಮೊದಲು ಪರಿಶೀಲಿಸಿ.\n"
                "ಇನ್ನಷ್ಟು ಪ್ರಶ್ನೆಗಳಿವೆಯೇ?"
            )
            
            # Save to history
            self.conversation_history.append({
                'query': query,
                'response': kannada_response,
                'timestamp': datetime.now().isoformat()
            })
            
            return full_response
            
        except Exception as e:
            return f"ಪ್ರಶ್ನೆ ಪ್ರಕ್ರಿಯೆಗೊಳಿಸುವಲ್ಲಿ ದೋಷ: {str(e)} / Error processing query: {str(e)}"

    def generate_audio(self, text):
        """Generate audio using dwani TTS."""
        try:
            if not text or not text.strip():
                return None
            
            # Clean text for TTS (remove markdown and special characters)
            clean_text = text.replace('**', '').replace('*', '').split('**ನಿರಾಕರಣೆ**')[0].strip()
            
            # Generate audio using dwani
            response = dwani.Audio.speech(input=clean_text[:500], response_format="wav")
            
            # Save to temporary file
            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".wav", dir='temp')
            temp_file.write(response)
            temp_file.close()
            
            self.temp_files.append(temp_file.name)
            return temp_file.name
            
        except Exception as e:
            print(f"TTS Error: {e}")
            return None

    def clear_history(self):
        """Clear conversation history."""
        self.conversation_history = []
        self.cleanup_temp_files()
        return "ಸಂಭಾಷಣೆ ಇತಿಹಾಸ ತೆರವುಗೊಳಿಸಲಾಗಿದೆ / Conversation history cleared."

    def get_conversation_history(self):
        """Get conversation history."""
        return self.conversation_history

    def generate_summary_report(self):
        """Generate summary report."""
        try:
            if not self.conversation_history:
                raise Exception("ಸಂಭಾಷಣೆ ಇತಿಹಾಸ ಖಾಲಿ / No conversation history")
            
            # Create summary
            summary_content = f"""
ಕಾನೂನು ಸಹಾಯಕ - ಸಾರಾಂಶ ವರದಿ
Legal Aid Assistant - Summary Report
ದಿನಾಂಕ / Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

ಸಂಭಾಷಣೆ ಸಾರಾಂಶ / Conversation Summary:
{'='*50}

"""
            
            for i, entry in enumerate(self.conversation_history, 1):
                summary_content += f"""
{i}. ಪ್ರಶ್ನೆ / Question:
{entry['query']}

ಉತ್ತರ / Answer:
{entry['response']}

ಸಮಯ / Time: {entry['timestamp']}
{'-'*30}
"""
            
            summary_content += f"""

**ನಿರಾಕರಣೆ / Disclaimer:**
ಈ ವರದಿಯು ಸಾಮಾನ್ಯ ಮಾಹಿತಿಗಾಗಿ ಮಾತ್ರ. ಕಾನೂನು ಸಲಹೆಗಾಗಿ ವಕೀಲರನ್ನು ಸಂಪರ್ಕಿಸಿ.
This report is for general information only. Consult a lawyer for legal advice.
"""
            
            # Save to file
            filename = f"legal_summary_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
            file_path = os.path.join('temp', filename)
            
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(summary_content)
            
            return file_path
            
        except Exception as e:
            raise Exception(f"ಸಾರಾಂಶ ರಚಿಸುವಲ್ಲಿ ದೋಷ: {str(e)} / Error generating summary: {str(e)}")

    def cleanup_temp_files(self):
        """Clean up temporary files."""
        for temp_file in self.temp_files:
            try:
                if os.path.exists(temp_file):
                    os.remove(temp_file)
            except:
                pass
        self.temp_files = []

    def __del__(self):
        self.cleanup_temp_files()
