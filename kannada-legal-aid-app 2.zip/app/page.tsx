"use client"

import  from "../frontend/static/js/legal_aid_locator"

export default function SyntheticV0PageForDeployment() {
  return < />
}