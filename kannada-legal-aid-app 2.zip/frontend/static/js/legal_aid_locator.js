class LegalAidLocator {
    constructor() {
        this.map = null;
        this.markers = [];
        this.currentLocationMarker = null;
        this.searchResults = [];
        this.userLocation = null;
        
        this.initializeElements();
        this.bindEvents();
        this.initializeMap();
        this.loadEmergencyContacts();
    }

    initializeElements() {
        // Input elements
        this.locationInput = document.getElementById('locationInput');
        this.legalTypeSelect = document.getElementById('legalTypeSelect');
        this.radiusSelect = document.getElementById('radiusSelect');
        this.sortSelect = document.getElementById('sortSelect');

        // Button elements
        this.searchBtn = document.getElementById('searchBtn');
        this.clearSearchBtn = document.getElementById('clearSearchBtn');
        this.getCurrentLocationBtn = document.getElementById('getCurrentLocationBtn');
        this.emergencyContactsBtn = document.getElementById('emergencyContactsBtn');
        this.toggleMapBtn = document.getElementById('toggleMapBtn');
        this.centerMapBtn = document.getElementById('centerMapBtn');

        // Display elements
        this.resultsList = document.getElementById('resultsList');
        this.resultsCount = document.getElementById('resultsCount');
        this.loadingOverlay = document.getElementById('loadingOverlay');
        this.toastContainer = document.getElementById('toastContainer');

        // Modal elements
        this.emergencyModal = document.getElementById('emergencyModal');
        this.centerModal = document.getElementById('centerModal');
        this.closeEmergencyModal = document.getElementById('closeEmergencyModal');
        this.closeCenterModal = document.getElementById('closeCenterModal');
        this.emergencyContacts = document.getElementById('emergencyContacts');
        this.centerDetails = document.getElementById('centerDetails');
        this.centerModalTitle = document.getElementById('centerModalTitle');
    }

    bindEvents() {
        this.searchBtn.addEventListener('click', () => this.searchLegalAid());
        this.clearSearchBtn.addEventListener('click', () => this.clearSearch());
        this.getCurrentLocationBtn.addEventListener('click', () => this.getCurrentLocation());
        this.emergencyContactsBtn.addEventListener('click', () => this.showEmergencyContacts());
        this.toggleMapBtn.addEventListener('click', () => this.toggleMapFullscreen());
        this.centerMapBtn.addEventListener('click', () => this.centerMap());

        // Modal events
        this.closeEmergencyModal.addEventListener('click', () => this.hideEmergencyContacts());
        this.closeCenterModal.addEventListener('click', () => this.hideCenterDetails());

        // Filter buttons
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.applyFilter(e.target.dataset.filter));
        });

        // Sort change
        this.sortSelect.addEventListener('change', () => this.sortResults());

        // Enter key search
        this.locationInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                this.searchLegalAid();
            }
        });

        // Click outside modal to close
        window.addEventListener('click', (e) => {
            if (e.target === this.emergencyModal) {
                this.hideEmergencyContacts();
            }
            if (e.target === this.centerModal) {
                this.hideCenterDetails();
            }
        });
    }

    initializeMap() {
        try {
            // Initialize Leaflet map
            this.map = L.map('map').setView([12.9716, 77.5946], 10); // Default to Bangalore

            // Add tile layer
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors',
                maxZoom: 18
            }).addTo(this.map);

            // Add map click event
            this.map.on('click', (e) => {
                this.onMapClick(e);
            });

            console.log('Map initialized successfully');
        } catch (error) {
            console.error('Error initializing map:', error);
            this.showToast('Error loading map. Please refresh the page.', 'error');
        }
    }

    async getCurrentLocation() {
        try {
            this.showLoading(true, 'Getting your location...');

            if (!navigator.geolocation) {
                throw new Error('Geolocation is not supported by this browser');
            }

            const position = await new Promise((resolve, reject) => {
                navigator.geolocation.getCurrentPosition(resolve, reject, {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 300000
                });
            });

            const { latitude, longitude } = position.coords;
            this.userLocation = { lat: latitude, lng: longitude };

            // Update map view
            this.map.setView([latitude, longitude], 13);

            // Add/update current location marker
            if (this.currentLocationMarker) {
                this.map.removeLayer(this.currentLocationMarker);
            }

            this.currentLocationMarker = L.marker([latitude, longitude], {
                icon: L.divIcon({
                    className: 'current-location-marker',
                    html: '<i class="fas fa-crosshairs"></i>',
                    iconSize: [30, 30]
                })
            }).addTo(this.map);

            this.currentLocationMarker.bindPopup('Your Current Location').openPopup();

            // Reverse geocode to get address
            try {
                const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`);
                const data = await response.json();
                
                if (data.display_name) {
                    this.locationInput.value = data.display_name.split(',')[0] + ', ' + data.address?.city || data.address?.town || '';
                }
            } catch (error) {
                console.error('Error reverse geocoding:', error);
            }

            this.showToast('Location detected successfully', 'success');
            
        } catch (error) {
            console.error('Error getting location:', error);
            this.showToast('Could not get your location. Please enter manually.', 'error');
        } finally {
            this.showLoading(false);
        }
    }

    async searchLegalAid() {
        try {
            const location = this.locationInput.value.trim();
            const legalType = this.legalTypeSelect.value;
            const radius = Number.parseInt(this.radiusSelect.value);

            if (!location) {
                this.showToast('Please enter a location', 'warning');
                return;
            }

            this.showLoading(true, 'Searching for legal aid centers...');

            const response = await fetch('/api/legal-aid/search', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    location: location,
                    legal_type: legalType,
                    radius: radius
                })
            });

            const result = await response.json();

            if (result.success) {
                this.searchResults = result.results;
                this.displayResults();
                this.updateMapMarkers();
                this.updateResultsCount();
                
                if (result.results.length === 0) {
                    this.showToast('No legal aid centers found in the specified area', 'warning');
                } else {
                    this.showToast(`Found ${result.results.length} legal aid centers`, 'success');
                }
            } else {
                this.showToast(`Search failed: ${result.error}`, 'error');
            }

        } catch (error) {
            console.error('Error searching legal aid:', error);
            this.showToast('Search failed. Please try again.', 'error');
        } finally {
            this.showLoading(false);
        }
    }

    displayResults() {
        this.resultsList.innerHTML = '';

        if (this.searchResults.length === 0) {
            this.resultsList.innerHTML = `
                <div class="no-results">
                    <i class="fas fa-search"></i>
                    <h4>No results found</h4>
                    <p>Try expanding your search radius or changing the location</p>
                </div>
            `;
            return;
        }

        this.searchResults.forEach((center, index) => {
            const resultCard = this.createResultCard(center, index);
            this.resultsList.appendChild(resultCard);
        });
    }

    createResultCard(center, index) {
        const card = document.createElement('div');
        card.className = 'result-card';
        card.innerHTML = `
            <div class="result-header">
                <div class="result-title">
                    <h4>${center.name}</h4>
                    <div class="result-type">${this.formatCenterType(center.type)}</div>
                </div>
                <div class="result-rating">
                    ${this.createRatingStars(center.rating)}
                    <span class="rating-value">${center.rating}</span>
                </div>
            </div>
            
            <div class="result-content">
                <div class="result-info">
                    <div class="info-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <span>${center.address}</span>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-phone"></i>
                        <span>${center.phone}</span>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-clock"></i>
                        <span>${center.timings}</span>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-route"></i>
                        <span>${center.distance} km away • ${center.estimated_travel_time}</span>
                    </div>
                </div>
                
                <div class="result-services">
                    <h6>Services:</h6>
                    <div class="service-tags">
                        ${center.services.map(service => `<span class="service-tag">${this.formatServiceName(service)}</span>`).join('')}
                    </div>
                </div>
                
                <div class="result-languages">
                    <h6>Languages:</h6>
                    <div class="language-tags">
                        ${center.languages.map(lang => `<span class="language-tag">${this.formatLanguageName(lang)}</span>`).join('')}
                    </div>
                </div>
            </div>
            
            <div class="result-actions">
                <button class="btn btn-outline btn-small" onclick="legalAidLocator.showCenterDetails(${center.id})">
                    <i class="fas fa-info-circle"></i>
                    Details
                </button>
                <button class="btn btn-outline btn-small" onclick="legalAidLocator.getDirections('${center.name}')">
                    <i class="fas fa-directions"></i>
                    Directions
                </button>
                <button class="btn btn-primary btn-small" onclick="legalAidLocator.contactCenter('${center.phone}')">
                    <i class="fas fa-phone"></i>
                    Call
                </button>
            </div>
        `;

        // Add click event to focus on map marker
        card.addEventListener('click', (e) => {
            if (!e.target.closest('.result-actions')) {
                this.focusOnMarker(index);
            }
        });

        return card;
    }

    updateMapMarkers() {
        // Clear existing markers (except current location)
        this.markers.forEach(marker => {
            this.map.removeLayer(marker);
        });
        this.markers = [];

        // Add markers for search results
        this.searchResults.forEach((center, index) => {
            const marker = L.marker([center.coordinates.lat, center.coordinates.lng], {
                icon: this.createCustomIcon(center.type)
            }).addTo(this.map);

            const popupContent = `
                <div class="marker-popup">
                    <h5>${center.name}</h5>
                    <p><strong>Type:</strong> ${this.formatCenterType(center.type)}</p>
                    <p><strong>Distance:</strong> ${center.distance} km</p>
                    <p><strong>Rating:</strong> ${center.rating}/5</p>
                    <div class="popup-actions">
                        <button onclick="legalAidLocator.showCenterDetails(${center.id})" class="btn btn-small">Details</button>
                        <button onclick="legalAidLocator.contactCenter('${center.phone}')" class="btn btn-small">Call</button>
                    </div>
                </div>
            `;

            marker.bindPopup(popupContent);
            this.markers.push(marker);
        });

        // Fit map to show all markers
        if (this.markers.length > 0) {
            const group = new L.featureGroup(this.markers);
            this.map.fitBounds(group.getBounds().pad(0.1));
        }
    }

    createCustomIcon(type) {
        const iconClass = this.getIconClass(type);
        return L.divIcon({
            className: 'custom-marker',
            html: `<i class="${iconClass}"></i>`,
            iconSize: [30, 30],
            iconAnchor: [15, 30]
        });
    }

    getIconClass(type) {
        const iconMap = {
            'state_authority': 'fas fa-university',
            'district_authority': 'fas fa-building',
            'legal_aid_society': 'fas fa-hands-helping',
            'ngo': 'fas fa-heart'
        };
        return iconMap[type] || 'fas fa-gavel';
    }

    createRatingStars(rating) {
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 !== 0;
        let starsHtml = '';

        for (let i = 0; i < fullStars; i++) {
            starsHtml += '<i class="fas fa-star"></i>';
        }

        if (hasHalfStar) {
            starsHtml += '<i class="fas fa-star-half-alt"></i>';
        }

        const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
        for (let i = 0; i < emptyStars; i++) {
            starsHtml += '<i class="far fa-star"></i>';
        }

        return starsHtml;
    }

    formatCenterType(type) {
        const typeMap = {
            'state_authority': 'State Legal Services Authority',
            'district_authority': 'District Legal Services Authority',
            'legal_aid_society': 'Legal Aid Society',
            'ngo': 'NGO'
        };
        return typeMap[type] || type;
    }

    formatServiceName(service) {
        const serviceMap = {
            'civil': 'Civil Law',
            'criminal': 'Criminal Law',
            'family': 'Family Law',
            'property': 'Property Law',
            'consumer': 'Consumer Rights',
            'labor': 'Labor Rights',
            'women_rights': 'Women Rights',
            'human_rights': 'Human Rights',
            'environmental': 'Environmental Law',
            'maritime': 'Maritime Law',
            'mining': 'Mining Law',
            'agricultural': 'Agricultural Law'
        };
        return serviceMap[service] || service;
    }

    formatLanguageName(language) {
        const languageMap = {
            'kannada': 'ಕನ್ನಡ',
            'english': 'English',
            'hindi': 'हिंदी',
            'marathi': 'मराठी',
            'tulu': 'ತುಳು',
            'konkani': 'कोंकणी',
            'urdu': 'اردو',
            'telugu': 'తెలుగు'
        };
        return languageMap[language] || language;
    }

    async showCenterDetails(centerId) {
        try {
            const center = this.searchResults.find(c => c.id === centerId);
            if (!center) {
                this.showToast('Center details not found', 'error');
                return;
            }

            this.centerModalTitle.textContent = center.name;
            this.centerDetails.innerHTML = `
                <div class="center-details-content">
                    <div class="detail-section">
                        <h5><i class="fas fa-info-circle"></i> Basic Information</h5>
                        <div class="detail-grid">
                            <div class="detail-item">
                                <span class="detail-label">Type:</span>
                                <span class="detail-value">${this.formatCenterType(center.type)}</span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Rating:</span>
                                <span class="detail-value">${this.createRatingStars(center.rating)} ${center.rating}/5</span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Distance:</span>
                                <span class="detail-value">${center.distance} km away</span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Travel Time:</span>
                                <span class="detail-value">${center.estimated_travel_time}</span>
                            </div>
                        </div>
                    </div>

                    <div class="detail-section">
                        <h5><i class="fas fa-map-marker-alt"></i> Contact Information</h5>
                        <div class="detail-grid">
                            <div class="detail-item">
                                <span class="detail-label">Address:</span>
                                <span class="detail-value">${center.address}</span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Phone:</span>
                                <span class="detail-value">
                                    <a href="tel:${center.phone}">${center.phone}</a>
                                </span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Email:</span>
                                <span class="detail-value">
                                    <a href="mailto:${center.email}">${center.email}</a>
                                </span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label">Timings:</span>
                                <span class="detail-value">${center.timings}</span>
                            </div>
                        </div>
                    </div>

                    <div class="detail-section">
                        <h5><i class="fas fa-gavel"></i> Services Offered</h5>
                        <div class="service-tags">
                            ${center.services.map(service => `<span class="service-tag">${this.formatServiceName(service)}</span>`).join('')}
                        </div>
                    </div>

                    <div class="detail-section">
                        <h5><i class="fas fa-language"></i> Languages Supported</h5>
                        <div class="language-tags">
                            ${center.languages.map(lang => `<span class="language-tag">${this.formatLanguageName(lang)}</span>`).join('')}
                        </div>
                    </div>

                    <div class="detail-section">
                        <h5><i class="fas fa-money-bill-wave"></i> Cost Information</h5>
                        <div class="cost-info">
                            ${center.free_services ? 
                                '<span class="free-badge"><i class="fas fa-check-circle"></i> Free Legal Services Available</span>' :
                                '<span class="paid-badge"><i class="fas fa-dollar-sign"></i> Paid Services</span>'
                            }
                        </div>
                    </div>

                    <div class="detail-actions">
                        <button onclick="legalAidLocator.contactCenter('${center.phone}')" class="btn btn-primary">
                            <i class="fas fa-phone"></i>
                            Call Now
                        </button>
                        <button onclick="legalAidLocator.getDirections('${center.name}')" class="btn btn-outline">
                            <i class="fas fa-directions"></i>
                            Get Directions
                        </button>
                        <button onclick="legalAidLocator.shareCenter(${center.id})" class="btn btn-outline">
                            <i class="fas fa-share"></i>
                            Share
                        </button>
                    </div>
                </div>
            `;

            this.centerModal.style.display = 'flex';

        } catch (error) {
            console.error('Error showing center details:', error);
            this.showToast('Error loading center details', 'error');
        }
    }

    hideCenterDetails() {
        this.centerModal.style.display = 'none';
    }

    async getDirections(centerName) {
        try {
            const startLocation = this.locationInput.value.trim();
            if (!startLocation) {
                this.showToast('Please enter your location first', 'warning');
                return;
            }

            this.showLoading(true, 'Getting directions...');

            const response = await fetch('/api/legal-aid/get-directions', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    start_location: startLocation,
                    end_location: centerName
                })
            });

            const result = await response.json();

            if (result.success) {
                // Open Google Maps with directions
                window.open(result.directions.map_url, '_blank');
                this.showToast('Directions opened in new tab', 'success');
            } else {
                this.showToast(`Error getting directions: ${result.error}`, 'error');
            }

        } catch (error) {
            console.error('Error getting directions:', error);
            this.showToast('Error getting directions', 'error');
        } finally {
            this.showLoading(false);
        }
    }

    contactCenter(phone) {
        if (confirm(`Call ${phone}?`)) {
            window.location.href = `tel:${phone}`;
        }
    }

    shareCenter(centerId) {
        const center = this.searchResults.find(c => c.id === centerId);
        if (!center) return;

        const shareText = `${center.name}\n${center.address}\nPhone: ${center.phone}\nRating: ${center.rating}/5`;

        if (navigator.share) {
            navigator.share({
                title: center.name,
                text: shareText,
                url: window.location.href
            });
        } else {
            // Fallback to clipboard
            navigator.clipboard.writeText(shareText).then(() => {
                this.showToast('Center details copied to clipboard', 'success');
            });
        }
    }

    async loadEmergencyContacts() {
        try {
            // For demo purposes, using static data
            const emergencyContacts = [
                {
                    name: "Karnataka State Legal Services Authority - Emergency",
                    phone: "+91-80-22217735",
                    email: "emergency@kslsa.karnataka.gov.in",
                    available: "24/7",
                    services: ["emergency_legal_aid", "bail_assistance", "urgent_consultation"]
                },
                {
                    name: "Women Helpline - Legal Support",
                    phone: "1091",
                    email: "women.helpline@karnataka.gov.in",
                    available: "24/7",
                    services: ["domestic_violence", "women_rights", "emergency_protection"]
                },
                {
                    name: "Child Helpline - Legal Aid",
                    phone: "1098",
                    email: "child.helpline@karnataka.gov.in",
                    available: "24/7",
                    services: ["child_protection", "custody_issues", "child_abuse"]
                },
                {
                    name: "Senior Citizen Helpline",
                    phone: "14567",
                    email: "senior.helpline@karnataka.gov.in",
                    available: "9 AM - 6 PM",
                    services: ["elder_abuse", "property_disputes", "pension_issues"]
                }
            ];

            this.emergencyContactsList = emergencyContacts;

        } catch (error) {
            console.error('Error loading emergency contacts:', error);
        }
    }

    showEmergencyContacts() {
        this.emergencyContacts.innerHTML = '';

        this.emergencyContactsList.forEach(contact => {
            const contactCard = document.createElement('div');
            contactCard.className = 'emergency-contact-card';
            contactCard.innerHTML = `
                <div class="contact-header">
                    <h5>${contact.name}</h5>
                    <span class="availability">${contact.available}</span>
                </div>
                <div class="contact-info">
                    <div class="contact-item">
                        <i class="fas fa-phone"></i>
                        <a href="tel:${contact.phone}">${contact.phone}</a>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-envelope"></i>
                        <a href="mailto:${contact.email}">${contact.email}</a>
                    </div>
                </div>
                <div class="contact-services">
                    <h6>Services:</h6>
                    <div class="service-tags">
                        ${contact.services.map(service => `<span class="service-tag">${service.replace(/_/g, ' ')}</span>`).join('')}
                    </div>
                </div>
                <div class="contact-actions">
                    <button onclick="legalAidLocator.contactCenter('${contact.phone}')" class="btn btn-primary btn-small">
                        <i class="fas fa-phone"></i>
                        Call Now
                    </button>
                </div>
            `;
            this.emergencyContacts.appendChild(contactCard);
        });

        this.emergencyModal.style.display = 'flex';
    }

    hideEmergencyContacts() {
        this.emergencyModal.style.display = 'none';
    }

    applyFilter(filterType) {
        // Toggle filter button active state
        const filterBtn = document.querySelector(`[data-filter="${filterType}"]`);
        filterBtn.classList.toggle('active');

        // Apply filter logic
        let filteredResults = [...this.searchResults];

        const activeFilters = Array.from(document.querySelectorAll('.filter-btn.active'))
            .map(btn => btn.dataset.filter);

        activeFilters.forEach(filter => {
            switch (filter) {
                case 'free_services':
                    filteredResults = filteredResults.filter(center => center.free_services);
                    break;
                case '24_7':
                    filteredResults = filteredResults.filter(center => 
                        center.timings.includes('24') || center.timings.includes('24/7')
                    );
                    break;
                case 'kannada_support':
                    filteredResults = filteredResults.filter(center => 
                        center.languages.includes('kannada')
                    );
                    break;
                case 'high_rated':
                    filteredResults = filteredResults.filter(center => center.rating >= 4.0);
                    break;
            }
        });

        // Update display with filtered results
        this.searchResults = filteredResults;
        this.displayResults();
        this.updateMapMarkers();
        this.updateResultsCount();
    }

    sortResults() {
        const sortBy = this.sortSelect.value;

        this.searchResults.sort((a, b) => {
            switch (sortBy) {
                case 'distance':
                    return a.distance - b.distance;
                case 'rating':
                    return b.rating - a.rating;
                case 'name':
