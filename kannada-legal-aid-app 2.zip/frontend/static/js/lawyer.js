class LawyerInterface {
  constructor() {
    this.mediaRecorder = null
    this.audioChunks = []
    this.isRecording = false
    this.uploadedFilePath = null
    this.conversationHistory = []

    this.initializeElements()
    this.bindEvents()
    this.setupKeyboardShortcuts()
    this.initializeFileUpload()
  }

  initializeElements() {
    // Buttons
    this.recordBtn = document.getElementById("recordBtn")
    this.stopRecordBtn = document.getElementById("stopRecordBtn")
    this.submitTextBtn = document.getElementById("submitTextBtn")
    this.clearHistoryBtn = document.getElementById("clearHistoryBtn")
    this.generateSummaryBtn = document.getElementById("generateSummaryBtn")
    this.exportChatBtn = document.getElementById("exportChatBtn")

    // Inputs
    this.textInput = document.getElementById("textInput")
    this.fileInput = document.getElementById("fileInput")
    this.fileDropZone = document.getElementById("fileDropZone")

    // Display elements
    this.chatContainer = document.getElementById("chatContainer")
    this.audioPlayer = document.getElementById("audioPlayer")
    this.audioPlaceholder = document.getElementById("audioPlaceholder")
    this.recordingIndicator = document.getElementById("recordingIndicator")
    this.fileInfo = document.getElementById("fileInfo")
    this.loadingOverlay = document.getElementById("loadingOverlay")
    this.toastContainer = document.getElementById("toastContainer")

    // Status elements
    this.statusValue = document.getElementById("statusValue")
    this.transcriptionValue = document.getElementById("transcriptionValue")
    this.conversationLength = document.getElementById("conversationLength")
  }

  bindEvents() {
    this.recordBtn.addEventListener("click", () => this.startRecording())
    this.stopRecordBtn.addEventListener("click", () => this.stopRecording())
    this.submitTextBtn.addEventListener("click", () => this.submitText())
    this.clearHistoryBtn.addEventListener("click", () => this.clearHistory())
    this.generateSummaryBtn.addEventListener("click", () => this.generateSummary())
    this.exportChatBtn.addEventListener("click", () => this.exportChat())
  }

  setupKeyboardShortcuts() {
    this.textInput.addEventListener("keydown", (e) => {
      if (e.ctrlKey && e.key === "Enter") {
        e.preventDefault()
        this.submitText()
      }
    })

    // Global shortcuts
    document.addEventListener("keydown", (e) => {
      if (e.ctrlKey && e.key === "r") {
        e.preventDefault()
        if (!this.isRecording) {
          this.startRecording()
        } else {
          this.stopRecording()
        }
      }
    })
  }

  initializeFileUpload() {
    // File drop zone events
    this.fileDropZone.addEventListener("click", () => this.fileInput.click())
    this.fileInput.addEventListener("change", (e) => this.handleFileUpload(e))

    // Drag and drop events
    this.fileDropZone.addEventListener("dragover", (e) => {
      e.preventDefault()
      this.fileDropZone.style.borderColor = "var(--primary-color)"
      this.fileDropZone.style.background = "rgba(37, 99, 235, 0.05)"
    })

    this.fileDropZone.addEventListener("dragleave", (e) => {
      e.preventDefault()
      this.fileDropZone.style.borderColor = "var(--gray-300)"
      this.fileDropZone.style.background = "var(--bg-secondary)"
    })

    this.fileDropZone.addEventListener("drop", (e) => {
      e.preventDefault()
      this.fileDropZone.style.borderColor = "var(--gray-300)"
      this.fileDropZone.style.background = "var(--bg-secondary)"

      const files = e.dataTransfer.files
      if (files.length > 0) {
        this.processFile(files[0])
      }
    })
  }

  async startRecording() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      this.mediaRecorder = new MediaRecorder(stream)
      this.audioChunks = []

      this.mediaRecorder.ondataavailable = (event) => {
        this.audioChunks.push(event.data)
      }

      this.mediaRecorder.onstop = () => {
        this.processRecording()
      }

      this.mediaRecorder.start()
      this.isRecording = true
      this.updateRecordingUI(true)
      this.updateStatus("Recording... Speak your question in Kannada")
    } catch (error) {
      console.error("Error accessing microphone:", error)
      this.showToast("Error: Could not access microphone. Please check permissions.", "error")
    }
  }

  stopRecording() {
    if (this.mediaRecorder && this.isRecording) {
      this.mediaRecorder.stop()
      this.mediaRecorder.stream.getTracks().forEach((track) => track.stop())
      this.isRecording = false
      this.updateRecordingUI(false)
      this.updateStatus("Processing recording...")
    }
  }

  async processRecording() {
    const audioBlob = new Blob(this.audioChunks, { type: "audio/wav" })
    const formData = new FormData()
    formData.append("audio", audioBlob, "recording.wav")

    try {
      this.showLoading(true)

      const response = await fetch("/api/lawyer/transcribe_audio", {
        method: "POST",
        body: formData,
      })

      const result = await response.json()

      if (result.success && result.transcription) {
        this.transcriptionValue.textContent = result.transcription
        this.addMessageToChat("user", `🎤 ${result.transcription}`)
        await this.processQuery(result.transcription)
      } else {
        this.showToast(`Transcription failed: ${result.error}`, "error")
      }
    } catch (error) {
      console.error("Error processing recording:", error)
      this.showToast("Error processing recording", "error")
    } finally {
      this.showLoading(false)
    }
  }

  async submitText() {
    const query = this.textInput.value.trim()
    if (!query) {
      this.showToast("Please enter a question", "warning")
      return
    }

    this.addMessageToChat("user", query)
    this.textInput.value = ""

    await this.processQuery(query)
  }

  async processQuery(query) {
    try {
      this.showLoading(true)
      this.updateStatus("Processing your query...")

      const requestData = {
        query: query,
        file_path: this.uploadedFilePath,
        generate_audio: true,
      }

      const response = await fetch("/api/lawyer/process_text", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestData),
      })

      const result = await response.json()

      if (result.success) {
        this.addMessageToChat("assistant", result.response)

        if (result.audio_path) {
          this.playAudio(result.audio_path)
        }

        this.conversationHistory = result.history || []
        this.updateConversationLength()
        this.updateStatus("Response generated successfully")
        this.showToast("Response generated successfully", "success")
      } else {
        this.showToast(`Error: ${result.error}`, "error")
      }
    } catch (error) {
      console.error("Error processing query:", error)
      this.showToast("Error processing query", "error")
    } finally {
      this.showLoading(false)
    }
  }

  async handleFileUpload(event) {
    const file = event.target.files[0]
    if (!file) return

    await this.processFile(file)
  }

  async processFile(file) {
    const formData = new FormData()
    formData.append("file", file)

    try {
      this.showLoading(true)
      this.updateStatus("Uploading file...")

      const response = await fetch("/api/lawyer/upload_file", {
        method: "POST",
        body: formData,
      })

      const result = await response.json()

      if (result.success) {
        this.uploadedFilePath = result.file_path
        this.fileInfo.textContent = `✓ File uploaded: ${file.name}`
        this.fileInfo.className = "file-info success"
        this.updateStatus("File uploaded successfully")
        this.showToast("File uploaded successfully", "success")
      } else {
        this.fileInfo.textContent = `✗ Upload failed: ${result.error}`
        this.fileInfo.className = "file-info error"
        this.showToast("File upload failed", "error")
      }
    } catch (error) {
      console.error("Error uploading file:", error)
      this.fileInfo.textContent = "✗ Upload failed: Network error"
      this.fileInfo.className = "file-info error"
      this.showToast("File upload failed", "error")
    } finally {
      this.showLoading(false)
    }
  }

  async clearHistory() {
    try {
      this.showLoading(true)

      const response = await fetch("/api/lawyer/clear_history", {
        method: "POST",
      })

      const result = await response.json()

      if (result.success) {
        this.clearChatContainer()
        this.uploadedFilePath = null
        this.fileInfo.textContent = ""
        this.fileInfo.className = "file-info"
        this.transcriptionValue.textContent = "None"
        this.conversationHistory = []
        this.updateConversationLength()
        this.updateStatus("History cleared")
        this.showToast("History cleared successfully", "success")
      } else {
        this.showToast("Error clearing history", "error")
      }
    } catch (error) {
      console.error("Error clearing history:", error)
      this.showToast("Error clearing history", "error")
    } finally {
      this.showLoading(false)
    }
  }

  async generateSummary() {
    try {
      this.showLoading(true)
      this.updateStatus("Generating summary report...")

      const response = await fetch("/api/lawyer/generate_summary", {
        method: "POST",
      })

      const result = await response.json()

      if (result.success) {
        // Create download link
        const link = document.createElement("a")
        link.href = `/download/${result.file_path}`
        link.download = "legal_summary_report.txt"
        link.click()

        this.updateStatus("Summary report downloaded")
        this.showToast("Summary report generated and downloaded", "success")
      } else {
        this.showToast(result.error || "Failed to generate summary", "error")
      }
    } catch (error) {
      console.error("Error generating summary:", error)
      this.showToast("Error generating summary", "error")
    } finally {
      this.showLoading(false)
    }
  }

  exportChat() {
    if (this.conversationHistory.length === 0) {
      this.showToast("No conversation to export", "warning")
      return
    }

    let chatText = "Kannada Legal Aid - Conversation Export\n"
    chatText += `Generated: ${new Date().toLocaleString()}\n`
    chatText += "=".repeat(50) + "\n\n"

    this.conversationHistory.forEach((entry, index) => {
      chatText += `${index + 1}. Question:\n${entry.query}\n\n`
      chatText += `Answer:\n${entry.response}\n\n`
      chatText += "-".repeat(30) + "\n\n"
    })

    const blob = new Blob([chatText], { type: "text/plain" })
    const link = document.createElement("a")
    link.href = URL.createObjectURL(blob)
    link.download = `legal_chat_${new Date().toISOString().split("T")[0]}.txt`
    link.click()

    this.showToast("Chat exported successfully", "success")
  }

  addMessageToChat(sender, message) {
    const messageDiv = document.createElement("div")
    messageDiv.className = `chat-message ${sender}`

    const timestamp = new Date().toLocaleTimeString()
    const avatar = document.createElement("div")
    avatar.className = "message-avatar"
    avatar.innerHTML = sender === "user" ? '<i class="fas fa-user"></i>' : '<i class="fas fa-robot"></i>'

    const content = document.createElement("div")
    content.className = "message-text"
    content.innerHTML = `
            ${this.formatMessage(message)}
            <div class="message-timestamp">${timestamp}</div>
        `

    messageDiv.appendChild(avatar)
    messageDiv.appendChild(content)

    this.chatContainer.appendChild(messageDiv)
    this.chatContainer.scrollTop = this.chatContainer.scrollHeight
  }

  formatMessage(message) {
    return message
      .replace(/\n/g, "<br>")
      .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
      .replace(/\*(.*?)\*/g, "<em>$1</em>")
  }

  playAudio(audioPath) {
    this.audioPlayer.src = `/audio/${audioPath}`
    this.audioPlayer.style.display = "block"
    this.audioPlaceholder.style.display = "none"

    this.audioPlayer.play().catch((error) => {
      console.error("Error playing audio:", error)
      this.showToast("Error playing audio", "error")
    })
  }

  updateRecordingUI(isRecording) {
    if (isRecording) {
      this.recordBtn.style.display = "none"
      this.stopRecordBtn.style.display = "inline-flex"
      this.recordingIndicator.classList.add("recording")
      this.recordingIndicator.querySelector("span").textContent = "Recording... Click stop when finished"
    } else {
      this.recordBtn.style.display = "inline-flex"
      this.stopRecordBtn.style.display = "none"
      this.recordingIndicator.classList.remove("recording")
      this.recordingIndicator.querySelector("span").textContent = "Ready to record..."
    }
  }

  updateStatus(message) {
    this.statusValue.textContent = message
  }

  updateConversationLength() {
    this.conversationLength.textContent = `${this.conversationHistory.length} messages`
  }

  clearChatContainer() {
    this.chatContainer.innerHTML = `
            <div class="welcome-message">
                <div class="assistant-avatar">
                    <i class="fas fa-robot"></i>
                </div>
                <div class="message-content">
                    <h4>ನಮಸ್ಕಾರ! ನಾನು ನಿಮ್ಮ ಕಾನೂನು ಸಹಾಯಕ</h4>
                    <p>I'm here to assist you with legal queries in Kannada. You can ask questions via voice or text, and upload documents for analysis.</p>
                </div>
            </div>
        `
  }

  showLoading(show) {
    this.loadingOverlay.style.display = show ? "flex" : "none"
  }

  showToast(message, type = "success") {
    const toast = document.createElement("div")
    toast.className = `toast ${type}`
    toast.innerHTML = `
            <div style="display: flex; align-items: center; gap: 0.5rem;">
                <i class="fas fa-${type === "success" ? "check-circle" : type === "error" ? "exclamation-circle" : "exclamation-triangle"}"></i>
                <span>${message}</span>
            </div>
        `

    this.toastContainer.appendChild(toast)

    // Auto remove after 5 seconds
    setTimeout(() => {
      if (toast.parentNode) {
        toast.parentNode.removeChild(toast)
      }
    }, 5000)

    // Click to dismiss
    toast.addEventListener("click", () => {
      if (toast.parentNode) {
        toast.parentNode.removeChild(toast)
      }
    })
  }
}

// Initialize the interface when the page loads
document.addEventListener("DOMContentLoaded", () => {
  new LawyerInterface()
})
