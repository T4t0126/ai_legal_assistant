class UserInterface {
    constructor() {
        this.mediaRecorder = null;
        this.audioChunks = [];
        this.isRecording = false;
        this.conversationHistory = [];
        
        this.initializeElements();
        this.bindEvents();
        this.setupKeyboardShortcuts();
        this.setupExampleQuestions();
    }

    initializeElements() {
        // Buttons
        this.recordBtn = document.getElementById('recordBtn');
        this.stopRecordBtn = document.getElementById('stopRecordBtn');
        this.submitTextBtn = document.getElementById('submitTextBtn');
        this.clearHistoryBtn = document.getElementById('clearHistoryBtn');

        // Inputs
        this.textInput = document.getElementById('textInput');

        // Display elements
        this.chatContainer = document.getElementById('chatContainer');
        this.keyPointsContainer = document.getElementById('keyPointsContainer');
        this.audioPlayer = document.getElementById('audioPlayer');
        this.audioPlaceholder = document.getElementById('audioPlaceholder');
        this.recordingIndicator = document.getElementById('recordingIndicator');
        this.loadingOverlay = document.getElementById('loadingOverlay');
        this.toastContainer = document.getElementById('toastContainer');

        // Status elements
        this.statusValue = document.getElementById('statusValue');
        this.lastQuestionValue = document.getElementById('lastQuestionValue');
    }

    bindEvents() {
        this.recordBtn.addEventListener('click', () => this.startRecording());
        this.stopRecordBtn.addEventListener('click', () => this.stopRecording());
        this.submitTextBtn.addEventListener('click', () => this.submitText());
        this.clearHistoryBtn.addEventListener('click', () => this.clearHistory());
    }

    setupKeyboardShortcuts() {
        this.textInput.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'Enter') {
                e.preventDefault();
                this.submitText();
            }
        });

        // Global shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.key === 'r') {
                e.preventDefault();
                if (!this.isRecording) {
                    this.startRecording();
                } else {
                    this.stopRecording();
                }
            }
        });
    }

    setupExampleQuestions() {
        document.querySelectorAll('.example-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const question = btn.getAttribute('data-question');
                this.textInput.value = question;
                this.submitText();
            });
        });
    }

    async startRecording() {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            this.mediaRecorder = new MediaRecorder(stream);
            this.audioChunks = [];

            this.mediaRecorder.ondataavailable = (event) => {
                this.audioChunks.push(event.data);
            };

            this.mediaRecorder.onstop = () => {
                this.processRecording();
            };

            this.mediaRecorder.start();
            this.isRecording = true;
            this.updateRecordingUI(true);
            this.updateStatus('Recording... Speak your question in Kannada');

        } catch (error) {
            console.error('Error accessing microphone:', error);
            this.showToast('Error: Could not access microphone. Please check permissions.', 'error');
        }
    }

    stopRecording() {
        if (this.mediaRecorder && this.isRecording) {
            this.mediaRecorder.stop();
            this.mediaRecorder.stream.getTracks().forEach(track => track.stop());
            this.isRecording = false;
            this.updateRecordingUI(false);
            this.updateStatus('Processing recording...');
        }
    }

    async processRecording() {
        const audioBlob = new Blob(this.audioChunks, { type: 'audio/wav' });
        const formData = new FormData();
        formData.append('audio', audioBlob, 'recording.wav');

        try {
            this.showLoading(true);
            
            const response = await fetch('/api/user/transcribe_audio', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();
            
            if (result.success && result.transcription) {
                this.lastQuestionValue.textContent = result.transcription;
                this.addMessageToChat('user', `🎤 ${result.transcription}`);
                await this.processQuery(result.transcription);
            } else {
                this.showToast(`Transcription failed: ${result.error}`, 'error');
            }

        } catch (error) {
            console.error('Error processing recording:', error);
            this.showToast('Error processing recording', 'error');
        } finally {
            this.showLoading(false);
        }
    }

    async submitText() {
        const query = this.textInput.value.trim();
        if (!query) {
            this.showToast('Please enter a question', 'warning');
            return;
        }

        this.lastQuestionValue.textContent = query;
        this.addMessageToChat('user', query);
        this.textInput.value = '';
        
        await this.processQuery(query);
    }

    async processQuery(query) {
        try {
            this.showLoading(true);
            this.updateStatus('Processing your question...');
            
            const requestData = {
                query: query,
                generate_audio: true
            };

            const response = await fetch('/api/user/process_text', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(requestData)
            });

            const result = await response.json();
            
            if (result.success) {
                this.addMessageToChat('assistant', result.response);
                
                if (result.key_points) {
                    this.updateKeyPoints(result.key_points);
                }
                
                if (result.audio_path) {
                    this.playAudio(result.audio_path);
                }
                
                this.conversationHistory = result.history || [];
                this.updateStatus('Response generated successfully');
                this.showToast('Response generated successfully', 'success');
            } else {
                this.showToast(`Error: ${result.error}`, 'error');
            }

        } catch (error) {
            console.error('Error processing query:', error);
            this.showToast('Error processing query', 'error');
        } finally {
            this.showLoading(false);
        }
    }

    async clearHistory() {
        try {
            this.showLoading(true);
            
            const response = await fetch('/api/user/clear_history', {
                method: 'POST'
            });

            const result = await response.json();
            
            if (result.success) {
                this.clearChatContainer();
                this.clearKeyPoints();
                this.lastQuestionValue.textContent = 'None';
                this.conversationHistory = [];
                this.updateStatus('History cleared');
                this.showToast('History cleared successfully', 'success');
            } else {
                this.showToast('Error clearing history', 'error');
            }

        } catch (error) {
            console.error('Error clearing history:', error);
            this.showToast('Error clearing history', 'error');
        } finally {
            this.showLoading(false);
        }
    }

    addMessageToChat(sender, message) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `chat-message ${sender}`;
        
        const timestamp = new Date().toLocaleTimeString();
        const avatar = document.createElement('div');
