// Main JavaScript for home page
document.addEventListener("DOMContentLoaded", () => {
  // Smooth scrolling for anchor links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault()
      const target = document.querySelector(this.getAttribute("href"))
      if (target) {
        target.scrollIntoView({
          behavior: "smooth",
          block: "start",
        })
      }
    })
  })

  // Add animation to interface cards on scroll
  const observerOptions = {
    threshold: 0.1,
    rootMargin: "0px 0px -50px 0px",
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = "1"
        entry.target.style.transform = "translateY(0)"
      }
    })
  }, observerOptions)

  // Observe interface cards and feature cards
  document.querySelectorAll(".interface-card, .feature-card, .step").forEach((card) => {
    card.style.opacity = "0"
    card.style.transform = "translateY(20px)"
    card.style.transition = "opacity 0.6s ease, transform 0.6s ease"
    observer.observe(card)
  })

  // Add hover effects to buttons
  document.querySelectorAll(".btn").forEach((button) => {
    button.addEventListener("mouseenter", function () {
      this.style.transform = "translateY(-2px)"
    })

    button.addEventListener("mouseleave", function () {
      this.style.transform = "translateY(0)"
    })
  })

  // Language toggle functionality (placeholder)
  const languageToggle = document.querySelector(".language-toggle")
  if (languageToggle) {
    languageToggle.addEventListener("click", () => {
      // Placeholder for language switching functionality
      console.log("Language toggle clicked")
    })
  }

  // Add loading animation to interface links
  document.querySelectorAll('a[href="/lawyer"], a[href="/user"]').forEach((link) => {
    link.addEventListener("click", function (e) {
      // Add loading state
      const originalText = this.innerHTML
      this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...'
      this.style.pointerEvents = "none"

      // Reset after a short delay (in case navigation fails)
      setTimeout(() => {
        this.innerHTML = originalText
        this.style.pointerEvents = "auto"
      }, 3000)
    })
  })
})
