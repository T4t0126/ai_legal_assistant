const CACHE_NAME = "kannada-legal-aid-v1.0.0"
const OFFLINE_URL = "/offline.html"

// Files to cache for offline functionality
const CACHE_URLS = [
  "/",
  "/offline.html",
  "/user",
  "/lawyer",
  "/legal-aid-locator",
  "/static/css/style.css",
  "/static/js/main.js",
  "/static/js/user.js",
  "/static/js/lawyer.js",
  "/static/js/legal_aid_locator.js",
  "/static/js/offline.js",
  "/static/manifest.json",
  "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css",
  "https://fonts.googleapis.com/css2?family=Noto+Sans+Kannada:wght@300;400;500;600;700&family=Inter:wght@300;400;500;600;700&display=swap",
]

// Install event - cache resources
self.addEventListener("install", (event) => {
  console.log("Service Worker: Installing...")

  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) => {
        console.log("Service Worker: Caching files")
        return cache.addAll(CACHE_URLS)
      })
      .then(() => {
        console.log("Service Worker: Installation complete")
        return self.skipWaiting()
      })
      .catch((error) => {
        console.error("Service Worker: Installation failed", error)
      }),
  )
})

// Activate event - clean up old caches
self.addEventListener("activate", (event) => {
  console.log("Service Worker: Activating...")

  event.waitUntil(
    caches
      .keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => {
            if (cacheName !== CACHE_NAME) {
              console.log("Service Worker: Deleting old cache", cacheName)
              return caches.delete(cacheName)
            }
          }),
        )
      })
      .then(() => {
        console.log("Service Worker: Activation complete")
        return self.clients.claim()
      }),
  )
})

// Fetch event - serve cached content when offline
self.addEventListener("fetch", (event) => {
  // Skip non-GET requests
  if (event.request.method !== "GET") {
    return
  }

  // Skip chrome-extension and other non-http requests
  if (!event.request.url.startsWith("http")) {
    return
  }

  event.respondWith(
    caches.match(event.request).then((response) => {
      // Return cached version if available
      if (response) {
        return response
      }

      // Try to fetch from network
      return fetch(event.request)
        .then((response) => {
          // Don't cache non-successful responses
          if (!response || response.status !== 200 || response.type !== "basic") {
            return response
          }

          // Clone the response for caching
          const responseToCache = response.clone()

          // Cache the response for future use
          caches.open(CACHE_NAME).then((cache) => {
            // Only cache GET requests for same origin
            if (event.request.url.startsWith(self.location.origin)) {
              cache.put(event.request, responseToCache)
            }
          })

          return response
        })
        .catch(() => {
          // Network failed, try to serve offline page for navigation requests
          if (event.request.mode === "navigate") {
            return caches.match(OFFLINE_URL)
          }

          // For other requests, return a generic offline response
          return new Response("Offline", {
            status: 503,
            statusText: "Service Unavailable",
            headers: new Headers({
              "Content-Type": "text/plain",
            }),
          })
        })
    }),
  )
})

// Background sync for offline data
self.addEventListener("sync", (event) => {
  console.log("Service Worker: Background sync triggered", event.tag)

  if (event.tag === "sync-offline-data") {
    event.waitUntil(syncOfflineData())
  }
})

// Push notification handling
self.addEventListener("push", (event) => {
  console.log("Service Worker: Push notification received")

  const options = {
    body: event.data ? event.data.text() : "New legal aid notification",
    icon: "/static/icons/icon-192x192.png",
    badge: "/static/icons/badge-72x72.png",
    vibrate: [200, 100, 200],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1,
    },
    actions: [
      {
        action: "explore",
        title: "Open App",
        icon: "/static/icons/action-open.png",
      },
      {
        action: "close",
        title: "Close",
        icon: "/static/icons/action-close.png",
      },
    ],
  }

  event.waitUntil(self.registration.showNotification("Kannada Legal Aid", options))
})

// Notification click handling
self.addEventListener("notificationclick", (event) => {
  console.log("Service Worker: Notification clicked", event)

  event.notification.close()

  if (event.action === "explore") {
    event.waitUntil(clients.openWindow("/"))
  } else if (event.action === "close") {
    // Just close the notification
    return
  } else {
    // Default action - open the app
    event.waitUntil(clients.openWindow("/"))
  }
})

// Message handling from main thread
self.addEventListener("message", (event) => {
  console.log("Service Worker: Message received", event.data)

  if (event.data && event.data.type === "SKIP_WAITING") {
    self.skipWaiting()
  }

  if (event.data && event.data.type === "CACHE_CONVERSATION") {
    cacheConversationData(event.data.payload)
  }

  if (event.data && event.data.type === "GET_CACHE_SIZE") {
    getCacheSize().then((size) => {
      event.ports[0].postMessage({ type: "CACHE_SIZE", size })
    })
  }
})

// Helper function to sync offline data
async function syncOfflineData() {
  try {
    console.log("Service Worker: Syncing offline data...")

    // Get offline conversations from IndexedDB or localStorage
    const offlineData = await getOfflineData()

    if (offlineData.length > 0) {
      const response = await fetch("/api/offline/sync-data", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          offline_conversations: offlineData,
        }),
      })

      if (response.ok) {
        console.log("Service Worker: Offline data synced successfully")
        await clearOfflineData()
      } else {
        console.error("Service Worker: Failed to sync offline data")
      }
    }
  } catch (error) {
    console.error("Service Worker: Error syncing offline data", error)
  }
}

// Helper function to cache conversation data
async function cacheConversationData(data) {
  try {
    const cache = await caches.open(CACHE_NAME)
    const response = new Response(JSON.stringify(data), {
      headers: { "Content-Type": "application/json" },
    })
    await cache.put("/cached-conversations", response)
    console.log("Service Worker: Conversation data cached")
  } catch (error) {
    console.error("Service Worker: Error caching conversation data", error)
  }
}

// Helper function to get cache size
async function getCacheSize() {
  try {
    const cacheNames = await caches.keys()
    let totalSize = 0

    for (const cacheName of cacheNames) {
      const cache = await caches.open(cacheName)
      const requests = await cache.keys()

      for (const request of requests) {
        const response = await cache.match(request)
        if (response) {
          const blob = await response.blob()
          totalSize += blob.size
        }
      }
    }

    return totalSize
  } catch (error) {
    console.error("Service Worker: Error calculating cache size", error)
    return 0
  }
}

// Helper function to get offline data (placeholder)
async function getOfflineData() {
  // This would typically read from IndexedDB or localStorage
  // For now, return empty array
  return []
}

// Helper function to clear offline data (placeholder)
async function clearOfflineData() {
  // This would typically clear IndexedDB or localStorage
  console.log("Service Worker: Offline data cleared")
}

// Periodic background sync (if supported)
self.addEventListener("periodicsync", (event) => {
  console.log("Service Worker: Periodic sync triggered", event.tag)

  if (event.tag === "sync-legal-updates") {
    event.waitUntil(syncLegalUpdates())
  }
})

// Helper function to sync legal updates
async function syncLegalUpdates() {
  try {
    console.log("Service Worker: Syncing legal updates...")

    const response = await fetch("/api/legal-updates")
    if (response.ok) {
      const updates = await response.json()

      // Cache the updates
      const cache = await caches.open(CACHE_NAME)
      await cache.put("/cached-legal-updates", new Response(JSON.stringify(updates)))

      console.log("Service Worker: Legal updates synced")
    }
  } catch (error) {
    console.error("Service Worker: Error syncing legal updates", error)
  }
}

// Error handling
self.addEventListener("error", (event) => {
  console.error("Service Worker: Error occurred", event.error)
})

self.addEventListener("unhandledrejection", (event) => {
  console.error("Service Worker: Unhandled promise rejection", event.reason)
})
